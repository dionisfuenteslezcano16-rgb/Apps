// ui/VideoToolboxOverlay.kt
package com.nouse.videomejora.ui

import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.nouse.videomejora.media.Preset
import kotlin.math.roundToInt

@Composable
fun VideoToolboxOverlay(
    isEnhanced: Boolean,
    onToggleEnhanced: (Boolean) -> Unit,
    currentPreset: Preset,
    onUpdatePreset: (Preset) -> Unit,
    onTakeSnapshot: () -> Unit,
    onToggleScreenOffAudio: () -> Unit,
    modifier: Modifier = Modifier
) {
    var isOpen by remember { mutableStateOf(false) }
    var isBubbleMode by remember { mutableStateOf(false) }
    var offsetX by remember { mutableFloatStateOf(0f) }
    var offsetY by remember { mutableFloatStateOf(100f) }

    Box(modifier = modifier.fillMaxSize()) {
        if (!isOpen) {
            if (isBubbleMode) {
                IconButton(
                    onClick = { isOpen = true },
                    modifier = Modifier
                        .offset { IntOffset(offsetX.roundToInt(), offsetY.roundToInt()) }
                        .pointerInput(Unit) {
                            detectDragGestures { change, dragAmount ->
                                change.consume()
                                offsetX += dragAmount.x
                                offsetY += dragAmount.y
                            }
                        }
                        .size(48.dp)
                        .clip(CircleShape)
                        .background(Color.Black.copy(alpha = 0.85f))
                ) {
                    Icon(Icons.Default.AutoFixHigh, contentDescription = "Visión Video Toolbox", tint = Color(0xFF00FF41))
                }
            } else {
                Surface(
                    onClick = { isOpen = true },
                    shape = RoundedCornerShape(topStart = 16.dp, bottomStart = 16.dp),
                    color = Color.Black.copy(alpha = 0.75f),
                    modifier = Modifier.align(Alignment.CenterEnd).width(28.dp).height(80.dp)
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Box(Modifier.width(3.dp).height(40.dp).background(Color(0xFF00FF41), RoundedCornerShape(2.dp)))
                    }
                }
            }
        }

        AnimatedVisibility(
            visible = isOpen,
            enter = slideInHorizontally(initialOffsetX = { it }),
            exit = slideOutHorizontally(targetOffsetX = { it }),
            modifier = Modifier.align(Alignment.CenterEnd)
        ) {
            Surface(
                shape = RoundedCornerShape(topStart = 20.dp, bottomStart = 20.dp),
                color = Color(0xFF0A0A0A).copy(alpha = 0.95f),
                modifier = Modifier.fillMaxHeight().width(280.dp).padding(vertical = 16.dp)
            ) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        Text("Visión Video Toolbox", fontWeight = FontWeight.Bold, color = Color.White, fontSize = 14.sp)
                        IconButton(onClick = { isOpen = false }) { Icon(Icons.Default.Close, contentDescription = null, tint = Color.LightGray) }
                    }

                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        Text("Mejora en tiempo real", fontSize = 13.sp, color = Color.White)
                        Switch(checked = isEnhanced, onCheckedChange = onToggleEnhanced, colors = SwitchDefaults.colors(checkedThumbColor = Color(0xFF00FF41)))
                    }

                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        Text("Audio 8D Binaural", fontSize = 13.sp, color = Color.White)
                        Checkbox(checked = currentPreset.eightD, onCheckedChange = { onUpdatePreset(currentPreset.copy(eightD = it)) })
                    }

                    Button(onClick = { onTakeSnapshot(); isOpen = false }, modifier = Modifier.fillMaxWidth()) {
                        Icon(Icons.Default.CameraAlt, contentDescription = null, tint = Color(0xFF00FF41))
                        Spacer(Modifier.width(8.dp))
                        Text("Captura HD", fontSize = 12.sp)
                    }

                    Button(onClick = { onToggleScreenOffAudio(); isOpen = false }, modifier = Modifier.fillMaxWidth()) {
                        Icon(Icons.Default.NightlightRound, contentDescription = null, tint = Color(0xFF00FF41))
                        Spacer(Modifier.width(8.dp))
                        Text("Sonido con pantalla apagada", fontSize = 12.sp)
                    }
                }
            }
        }
    }
}
