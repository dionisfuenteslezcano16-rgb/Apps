// media/LivePlayerEngine.kt
package com.nouse.videomejora.media

import android.content.Context
import android.net.Uri
import androidx.annotation.OptIn
import androidx.media3.common.MediaItem
import androidx.media3.common.audio.AudioProcessor
import androidx.media3.common.util.UnstableApi
import androidx.media3.effect.Contrast
import androidx.media3.effect.Effect
import androidx.media3.effect.HslAdjustment
import androidx.media3.exoplayer.DefaultRenderersFactory
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.audio.AudioSink
import androidx.media3.exoplayer.audio.DefaultAudioSink

/**
 * Conecta los shaders GLSL (SharpenEffect) y el audio 8D (EightDProcessor)
 * directamente a ExoPlayer en tiempo real para reproducción continua,
 * con aceleración por hardware nativa (latencia cero).
 */
@OptIn(UnstableApi::class)
class LivePlayerEngine(private val context: Context) {
    var player: ExoPlayer? = null
        private set

    fun initializePlayer(uri: Uri, preset: Preset): ExoPlayer {
        release()

        val effects = buildList<Effect> {
            if (preset.contrast != 0f) add(Contrast(preset.contrast))
            if (preset.saturation != 0f)
                add(HslAdjustment.Builder().adjustSaturation(preset.saturation).build())
            if (preset.sharpen > 0f) add(SharpenEffect(preset.sharpen))
        }

        val audioProcessors: Array<AudioProcessor> = if (preset.eightD) {
            arrayOf(EightDProcessor(preset.hz, preset.reverbWet, voiceCentered = preset.voiceCentered))
        } else {
            emptyArray()
        }

        val renderersFactory = object : DefaultRenderersFactory(context) {
            override fun buildAudioSink(
                context: Context,
                enableFloatOutput: Boolean,
                enableAudioTrackPlaybackParams: Boolean
            ): AudioSink = DefaultAudioSink.Builder(context)
                .setEnableFloatOutput(enableFloatOutput)
                .setEnableAudioTrackPlaybackParams(enableAudioTrackPlaybackParams)
                .setAudioProcessors(audioProcessors)
                .build()
        }

        val exo = ExoPlayer.Builder(context, renderersFactory)
            .build()
            .apply {
                setVideoEffects(effects)
                setMediaItem(MediaItem.fromUri(uri))
                prepare()
            }

        player = exo
        return exo
    }

    fun updateEffects(preset: Preset) {
        val effects = buildList<Effect> {
            if (preset.contrast != 0f) add(Contrast(preset.contrast))
            if (preset.saturation != 0f)
                add(HslAdjustment.Builder().adjustSaturation(preset.saturation).build())
            if (preset.sharpen > 0f) add(SharpenEffect(preset.sharpen))
        }
        player?.setVideoEffects(effects)
    }

    fun release() {
        player?.release()
        player = null
    }
}
