// ui/ExportViewModel.kt
package com.nouse.videomejora.ui

import android.app.Application
import android.net.Uri
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.core.net.toUri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.work.*
import com.nouse.videomejora.media.Preset
import com.nouse.videomejora.media.Presets
import com.nouse.videomejora.work.ExportWorker
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.serialization.json.Json
import java.util.UUID

sealed interface UiState {
    data object Idle : UiState
    data class Running(val progress: Int) : UiState
    data class Done(val uri: Uri) : UiState
    data class Error(val msg: String) : UiState
}

class ExportViewModel(app: Application) : AndroidViewModel(app) {
    private val wm = WorkManager.getInstance(app)
    private val _state = MutableStateFlow<UiState>(UiState.Idle)
    val state = _state.asStateFlow()

    var inputUri by mutableStateOf<Uri?>(null)
    var preset by mutableStateOf(Presets.LIGERA)
    private var workId: UUID? = null

    fun start() {
        val uri = inputUri ?: return
        val req = OneTimeWorkRequestBuilder<ExportWorker>()
            .setInputData(workDataOf(
                ExportWorker.KEY_URI to uri.toString(),
                ExportWorker.KEY_PRESET to Json.encodeToString(Preset.serializer(), preset)
            ))
            .build()
        workId = req.id
        wm.enqueue(req)
        viewModelScope.launch {
            wm.getWorkInfoByIdFlow(req.id).collect { info ->
                _state.value = when (info?.state) {
                    WorkInfo.State.ENQUEUED, WorkInfo.State.RUNNING ->
                        UiState.Running(info.progress.getInt(ExportWorker.KEY_PROGRESS, 0))
                    WorkInfo.State.SUCCEEDED ->
                        UiState.Done(info.outputData.getString(ExportWorker.KEY_OUTPUT)!!.toUri())
                    WorkInfo.State.FAILED ->
                        UiState.Error(info.outputData.getString(ExportWorker.KEY_ERROR) ?: "Error")
                    WorkInfo.State.CANCELLED -> UiState.Idle
                    else -> UiState.Idle
                }
            }
        }
    }

    fun cancel() { workId?.let { wm.cancelWorkById(it) } }
    fun reset() { _state.value = UiState.Idle }
}
