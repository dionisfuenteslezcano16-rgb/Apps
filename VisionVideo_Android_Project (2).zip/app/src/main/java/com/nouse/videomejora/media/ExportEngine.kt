// media/ExportEngine.kt
package com.nouse.videomejora.media

import android.content.Context
import android.net.Uri
import androidx.annotation.OptIn
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.audio.AudioProcessor
import androidx.media3.common.util.UnstableApi
import androidx.media3.effect.Contrast
import androidx.media3.effect.Effect
import androidx.media3.effect.HslAdjustment
import androidx.media3.effect.ScaleAndRotateTransformation
import androidx.media3.transformer.*
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import java.io.File

@OptIn(UnstableApi::class)
class ExportEngine(private val context: Context) {

    /** Debe llamarse desde un hilo con Looper; usa Dispatchers.Main internamente. */
    suspend fun export(uri: Uri, preset: Preset, outFile: File, onProgress: (Int) -> Unit) =
        withContext(Dispatchers.Main) {
            val videoEffects = buildList<Effect> {
                if (preset.contrast != 0f) add(Contrast(preset.contrast))
                if (preset.saturation != 0f)
                    add(HslAdjustment.Builder().adjustSaturation(preset.saturation).build())
                if (preset.sharpen > 0f) add(SharpenEffect(preset.sharpen))
                if (preset.upscale > 1f)
                    add(ScaleAndRotateTransformation.Builder()
                        .setScale(preset.upscale, preset.upscale).build())
            }

            val audioProcessors = if (preset.eightD) {
                listOf<AudioProcessor>(
                    EightDProcessor(preset.hz, preset.reverbWet, voiceCentered = preset.voiceCentered)
                )
            } else {
                emptyList()
            }

            val transformer = Transformer.Builder(context)
                .setVideoMimeType(MimeTypes.VIDEO_H264)
                .setAudioMimeType(MimeTypes.AUDIO_AAC)
                .build()

            // MEJORA: Recorte sin recodificación previa (ClippingConfiguration)
            val mediaItemBuilder = MediaItem.Builder().setUri(uri)
            if (preset.endMs > preset.startMs && preset.endMs > 0L) {
                mediaItemBuilder.setClippingConfiguration(
                    MediaItem.ClippingConfiguration.Builder()
                        .setStartPositionMs(preset.startMs)
                        .setEndPositionMs(preset.endMs)
                        .build()
                )
            }

            val editedMediaItem = EditedMediaItem.Builder(mediaItemBuilder.build())
                .setEffects(Effects(audioProcessors, videoEffects))
                .build()

            val sequence = EditedMediaItemSequence.Builder(listOf(editedMediaItem)).build()

            val composition = Composition.Builder(listOf(sequence))
                // PERO HDR resuelto: todo pasa a SDR antes de nuestros shaders SDR.
                // (Rotación por metadatos la gestiona Transformer automáticamente.)
                .setHdrMode(Composition.HDR_MODE_TONE_MAP_HDR_TO_SDR_USING_OPEN_GL)
                .build()

            val done = CompletableDeferred<Unit>()
            transformer.addListener(object : Transformer.Listener {
                override fun onCompleted(c: Composition, r: ExportResult) {
                    done.complete(Unit)
                }
                override fun onError(c: Composition, r: ExportResult, e: ExportException) {
                    done.completeExceptionally(e)
                }
            })

            outFile.parentFile?.mkdirs()
            transformer.start(composition, outFile.absolutePath)

            try {
                while (!done.isCompleted) {
                    val h = Transformer.ProgressHolder()
                    if (transformer.getProgress(h) == Transformer.PROGRESS_STATE_AVAILABLE)
                        onProgress(h.progress)
                    delay(400)
                }
                done.await()
            } catch (e: CancellationException) {
                transformer.cancel() // cancelación limpia del codec/GL
                throw e
            }
        }
}
