// media/SharpenEffect.kt
package com.nouse.videomejora.media

import android.content.Context
import android.opengl.GLES20
import androidx.annotation.OptIn
import androidx.media3.common.VideoFrameProcessingException
import androidx.media3.common.util.GlProgram
import androidx.media3.common.util.GlUtil
import androidx.media3.common.util.Size
import androidx.media3.common.util.UnstableApi
import androidx.media3.effect.BaseGlShaderProgram
import androidx.media3.effect.GlEffect
import androidx.media3.effect.GlShaderProgram

@OptIn(UnstableApi::class)
class SharpenEffect(private val amount: Float) : GlEffect {
    override fun toGlShaderProgram(context: Context, useHdr: Boolean): GlShaderProgram =
        SharpenProgram(useHdr, amount)
}

@OptIn(UnstableApi::class)
private class SharpenProgram(useHdr: Boolean, private val amount: Float) :
    BaseGlShaderProgram(useHdr, 1) {

    private val program = GlProgram(VERTEX, FRAGMENT).apply {
        setBufferAttribute(
            "aPosition",
            GlUtil.getNormalizedCoordinateBounds(),
            GlUtil.HOMOGENEOUS_COORDINATE_VECTOR_SIZE
        )
    }

    private var texelX = 1f / 1280f
    private var texelY = 1f / 720f

    override fun configure(inputWidth: Int, inputHeight: Int): Size {
        texelX = 1f / inputWidth.coerceAtLeast(1)
        texelY = 1f / inputHeight.coerceAtLeast(1)
        return Size(inputWidth, inputHeight)
    }

    override fun drawFrame(inputTexId: Int, presentationTimeUs: Long) {
        try {
            program.use()
            program.setSamplerTexIdUniform("uTexSampler", inputTexId, 0)
            program.setFloatUniform("uAmount", amount)
            program.setFloatsUniform("uTexel", floatArrayOf(texelX, texelY))
            program.bindAttributesAndUniforms()
            GLES20.glDrawArrays(GLES20.GL_TRIANGLE_STRIP, 0, 4)
        } catch (e: GlUtil.GlException) {
            throw VideoFrameProcessingException(e, presentationTimeUs)
        }
    }

    override fun release() {
        super.release()
        try {
            program.delete()
        } catch (e: GlUtil.GlException) {
            throw VideoFrameProcessingException(e)
        }
    }

    private companion object {
        const val VERTEX = """
            attribute vec4 aPosition;
            varying vec2 vTexCoord;
            void main() {
                gl_Position = aPosition;
                vTexCoord = aPosition.xy * 0.5 + 0.5;
            }
        """
        const val FRAGMENT = """
            precision mediump float;
            uniform sampler2D uTexSampler;
            uniform vec2 uTexel;
            uniform float uAmount;
            varying vec2 vTexCoord;
            void main() {
                vec3 c = texture2D(uTexSampler, vTexCoord).rgb;
                vec3 blur = (
                    texture2D(uTexSampler, vTexCoord + vec2(uTexel.x, 0.0)).rgb +
                    texture2D(uTexSampler, vTexCoord - vec2(uTexel.x, 0.0)).rgb +
                    texture2D(uTexSampler, vTexCoord + vec2(0.0, uTexel.y)).rgb +
                    texture2D(uTexSampler, vTexCoord - vec2(0.0, uTexel.y)).rgb
                ) * 0.25;
                gl_FragColor = vec4(clamp(c + (c - blur) * uAmount, 0.0, 1.0), 1.0);
            }
        """
    }
}
