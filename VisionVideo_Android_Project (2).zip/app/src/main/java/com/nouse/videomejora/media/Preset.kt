// media/Preset.kt
package com.nouse.videomejora.media

import kotlinx.serialization.Serializable

@Serializable
data class Preset(
    val sharpen: Float = 0f,          // 0..1.5
    val contrast: Float = 0f,         // -1..1
    val saturation: Float = 0f,       // -100..100
    val upscale: Float = 1f,          // 1..2 (reescalado NO-IA, interpolado)
    val eightD: Boolean = false,
    val hz: Float = 0.09f,            // vueltas/segundo del giro 8D
    val reverbWet: Float = 0.25f,     // 0..1
    val voiceCentered: Boolean = false, // MEJORA: ancla voz en el centro, rota instrumentos (anti-mareo)
    val startMs: Long = 0L,           // MEJORA: Recorte de inicio (MediaItem.ClippingConfiguration)
    val endMs: Long = 0L              // MEJORA: Recorte de fin
)

object Presets {
    val LIGERA = Preset(sharpen = 0.4f, contrast = 0.05f, saturation = 8f)
    val NITIDEZ = Preset(sharpen = 0.9f, contrast = 0.08f, saturation = 12f)
    val OCHO_SUAVE = Preset(eightD = true, hz = 0.07f, reverbWet = 0.20f)
    val OCHO_INTENSO = Preset(eightD = true, hz = 0.12f, reverbWet = 0.35f)
    val VOZ_SEGURA = Preset(sharpen = 0.5f, contrast = 0.06f, saturation = 8f, eightD = true, hz = 0.08f, reverbWet = 0.22f, voiceCentered = true)

    val ALL = listOf(
        "Mejora ligera" to LIGERA,
        "Nitidez+" to NITIDEZ,
        "8D suave" to OCHO_SUAVE,
        "8D intenso" to OCHO_INTENSO,
        "8D Voz Segura" to VOZ_SEGURA
    )
}
