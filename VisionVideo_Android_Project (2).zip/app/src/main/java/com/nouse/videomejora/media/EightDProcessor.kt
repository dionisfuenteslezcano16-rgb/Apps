// media/EightDProcessor.kt
package com.nouse.videomejora.media

import androidx.annotation.OptIn
import androidx.media3.common.C
import androidx.media3.common.audio.AudioProcessor
import androidx.media3.common.audio.BaseAudioProcessor
import androidx.media3.common.util.UnstableApi
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

/**
 * 8D: paneo equal-power giratorio + reverb estéreo (2 comb filters con crossfeed).
 * Incluye modo voiceCentered opcional para eliminar el mareo en diálogos vocales.
 */
@OptIn(UnstableApi::class)
class EightDProcessor(
    private val hz: Float = 0.09f,
    private val reverbWet: Float = 0.25f,
    private val stereoKeep: Float = 0.15f,
    private val voiceCentered: Boolean = false
) : BaseAudioProcessor() {

    private var inChannels = 2
    private var phase = 0.0
    private var dPhase = 0.0
    private var delayL = FloatArray(1)
    private var delayR = FloatArray(1)
    private var posL = 0
    private var posR = 0

    override fun onConfigure(input: AudioProcessor.AudioFormat): AudioProcessor.AudioFormat {
        // El pipeline de Transformer entrega PCM 16-bit; si no, bypass elegante.
        if (input.encoding != C.ENCODING_PCM_16BIT || input.channelCount !in 1..2) {
            return AudioProcessor.AudioFormat.NOT_SET
        }
        inChannels = input.channelCount
        dPhase = 2.0 * PI * hz / input.sampleRate
        delayL = FloatArray((input.sampleRate * 0.050).toInt().coerceAtLeast(1))
        delayR = FloatArray((input.sampleRate * 0.090).toInt().coerceAtLeast(1))
        return AudioProcessor.AudioFormat(input.sampleRate, 2, C.ENCODING_PCM_16BIT)
    }

    override fun queueInput(inputBuffer: ByteBuffer) {
        if (!inputBuffer.hasRemaining()) return
        inputBuffer.order(ByteOrder.LITTLE_ENDIAN)
        val frames = inputBuffer.remaining() / (2 * inChannels)
        val out = replaceOutputBuffer(frames * 4) // estéreo 16-bit
        out.order(ByteOrder.LITTLE_ENDIAN)

        for (i in 0 until frames) {
            val l = inputBuffer.short.toFloat()
            val r = if (inChannels == 2) inputBuffer.short.toFloat() else l
            val mid = (l + r) * 0.5f
            val side = (l - r) * stereoKeep

            val theta = (sin(phase) + 1.0) * PI / 4.0
            phase += dPhase
            if (phase >= 2 * PI) phase -= 2 * PI

            // Modo anti-mareo: ancla un 55% de energía vocal en el centro fantasma
            val dryL = if (voiceCentered) {
                val voiceAnchor = 0.55f
                val rot = mid * cos(theta).toFloat()
                val center = mid * 0.707f
                rot * (1f - voiceAnchor) + center * voiceAnchor + side
            } else {
                (mid * cos(theta) + side).toFloat()
            }

            val dryR = if (voiceCentered) {
                val voiceAnchor = 0.55f
                val rot = mid * sin(theta).toFloat()
                val center = mid * 0.707f
                rot * (1f - voiceAnchor) + center * voiceAnchor - side
            } else {
                (mid * sin(theta) - side).toFloat()
            }

            val wetL = delayL[posL]
            delayL[posL] = dryL + wetL * 0.35f
            posL = (posL + 1) % delayL.size
            val wetR = delayR[posR]
            delayR[posR] = dryR + wetR * 0.20f
            posR = (posR + 1) % delayR.size

            val outL = dryL * (1 - reverbWet) + (wetL * 0.7f + wetR * 0.3f) * reverbWet
            val outR = dryR * (1 - reverbWet) + (wetR * 0.7f + wetL * 0.3f) * reverbWet
            out.putShort(clamp(outL))
            out.putShort(clamp(outR))
        }
        out.flip()
    }

    override fun onReset() {
        phase = 0.0; posL = 0; posR = 0
        delayL.fill(0f); delayR.fill(0f)
    }

    private fun clamp(v: Float): Short = v.coerceIn(-32768f, 32767f).toInt().toShort()
}
