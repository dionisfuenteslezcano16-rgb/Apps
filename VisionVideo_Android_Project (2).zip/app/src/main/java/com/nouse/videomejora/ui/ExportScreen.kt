// ui/ExportScreen.kt
package com.nouse.videomejora.ui

import android.Manifest
import android.content.Intent
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.nouse.videomejora.media.Presets

@Composable
fun ExportScreen(vm: ExportViewModel = viewModel()) {
    val state by vm.state.collectAsState()
    val ctx = LocalContext.current

    val picker = rememberLauncherForActivityResult(
        ActivityResultContracts.PickVisualMedia()
    ) { uri -> if (uri != null) vm.inputUri = uri }

    val notifPerm = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { }
    LaunchedEffect(Unit) {
        if (Build.VERSION.SDK_INT >= 33)
            notifPerm.launch(Manifest.permission.POST_NOTIFICATIONS)
    }

    Column(Modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Text("VideoMejora", style = MaterialTheme.typography.headlineMedium)

        Button(onClick = {
            picker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.VideoOnly))
        }) { Text(if (vm.inputUri == null) "Elegir video" else "Video elegido ✓") }

        Text("Preset", style = MaterialTheme.typography.titleMedium)
        Presets.ALL.forEach { (name, p) ->
            FilterChip(
                selected = vm.preset == p,
                onClick = { vm.preset = p },
                label = { Text(name) }
            )
        }

        // 8D es opt-in por preset: nunca se aplica a diálogo por accidente.
        Row(verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
            Checkbox(checked = vm.preset.eightD, onCheckedChange = {
                vm.preset = vm.preset.copy(eightD = it)
            })
            Text("Efecto 8D (recomendado solo para música, con audífonos)")
        }
        if (vm.preset.eightD) {
            Text("Velocidad de giro: ${"%.2f".format(vm.preset.hz)} Hz")
            Slider(value = vm.preset.hz, onValueChange = { vm.preset = vm.preset.copy(hz = it) },
                valueRange = 0.03f..0.2f)
            Text("Reverb: ${(vm.preset.reverbWet * 100).toInt()}%")
            Slider(value = vm.preset.reverbWet, onValueChange = { vm.preset = vm.preset.copy(reverbWet = it) },
                valueRange = 0f..0.6f)
            Row(verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                Checkbox(checked = vm.preset.voiceCentered, onCheckedChange = {
                    vm.preset = vm.preset.copy(voiceCentered = it)
                })
                Text("Anclar voz en el centro (Anti-mareo en diálogos)")
            }
        }
        Text("Nitidez: ${"%.1f".format(vm.preset.sharpen)}")
        Slider(value = vm.preset.sharpen, onValueChange = { vm.preset = vm.preset.copy(sharpen = it) },
            valueRange = 0f..1.5f)

        when (val s = state) {
            is UiState.Idle, is UiState.Error -> {
                if (s is UiState.Error) Text("Error: ${s.msg}", color = MaterialTheme.colorScheme.error)
                Button(
                    onClick = { vm.start() },
                    enabled = vm.inputUri != null,
                    modifier = Modifier.fillMaxWidth()
                ) { Text("Exportar") }
            }
            is UiState.Running -> {
                LinearProgressIndicator(progress = { s.progress / 100f }, modifier = Modifier.fillMaxWidth())
                Text("Exportando… ${s.progress}%")
                OutlinedButton(onClick = { vm.cancel() }) { Text("Cancelar") }
            }
            is UiState.Done -> {
                Text("Listo ✓ Guardado en Películas/VideoMejora")
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Button(onClick = {
                        ctx.startActivity(Intent.createChooser(
                            Intent(Intent.ACTION_SEND).apply {
                                type = "video/mp4"
                                putExtra(Intent.EXTRA_STREAM, s.uri)
                                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                            }, "Compartir"))
                    }) { Text("Compartir") }
                    OutlinedButton(onClick = { vm.reset() }) { Text("Otro") }
                }
            }
        }
    }
}
