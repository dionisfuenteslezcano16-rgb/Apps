// work/ExportWorker.kt
package com.nouse.videomejora.work

import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.PowerManager
import androidx.core.app.NotificationCompat
import androidx.core.net.toUri
import androidx.work.*
import com.nouse.videomejora.data.GallerySaver
import com.nouse.videomejora.media.ExportEngine
import com.nouse.videomejora.media.Preset
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.delay
import kotlinx.serialization.json.Json
import java.io.File

class ExportWorker(ctx: Context, params: WorkerParameters) : CoroutineWorker(ctx, params) {

    override suspend fun getForegroundInfo(): ForegroundInfo = foregroundInfo(0)

    override suspend fun doWork(): Result {
        val uri = inputData.getString(KEY_URI)!!.toUri()
        val preset = Json.decodeFromString<Preset>(inputData.getString(KEY_PRESET)!!)
        val tmp = File(applicationContext.cacheDir, "exports/$id.mp4")

        return try {
            setForeground(foregroundInfo(0))
            awaitCoolDown() // PERO térmica: no empezamos si el SoC ya está caliente
            ExportEngine(applicationContext).export(uri, preset, tmp) { p ->
                setProgressAsync(workDataOf(KEY_PROGRESS to p))
                notify(p)
            }
            val saved = GallerySaver.save(
                applicationContext, tmp, "Mejora_${System.currentTimeMillis()}.mp4"
            )
            tmp.delete()
            Result.success(workDataOf(KEY_OUTPUT to saved.toString()))
        } catch (e: CancellationException) {
            tmp.delete(); throw e
        } catch (e: Exception) {
            tmp.delete()
            Result.failure(workDataOf(KEY_ERROR to (e.message ?: "Error de exportación")))
        }
    }

    // Android 15+ mata el FGS mediaProcessing tras el límite; WorkManager nos para
    // y limpiamos el temporal. 6 h acumuladas sobran para clips; contenido largo -> nube.
    override suspend fun onStopped() {
        File(applicationContext.cacheDir, "exports/$id.mp4").delete()
    }

    private suspend fun awaitCoolDown() {
        if (Build.VERSION.SDK_INT < 29) return
        val pm = applicationContext.getSystemService(PowerManager::class.java)
        while (pm.currentThermalStatus >= PowerManager.THERMAL_STATUS_MODERATE) delay(5_000)
    }

    private fun foregroundInfo(progress: Int): ForegroundInfo {
        val nm = applicationContext.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL, "Exportación", NotificationManager.IMPORTANCE_LOW)
        )
        val n = NotificationCompat.Builder(applicationContext, CHANNEL)
            .setSmallIcon(android.R.drawable.stat_sys_download)
            .setContentTitle("Mejorando video")
            .setContentText("$progress%")
            .setOngoing(true)
            .build()
        // PERO Android 14/15: tipo de FGS correcto por versión, o crash.
        val type = when {
            Build.VERSION.SDK_INT >= 35 -> ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROCESSING
            Build.VERSION.SDK_INT >= 29 -> ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC
            else -> 0
        }
        return if (type != 0) ForegroundInfo(NOTIF_ID, n, type) else ForegroundInfo(NOTIF_ID, n)
    }

    private fun notify(progress: Int) {
        val nm = applicationContext.getSystemService(NotificationManager::class.java)
        nm.notify(NOTIF_ID, foregroundInfo(progress).notification)
    }

    companion object {
        const val KEY_URI = "uri"; const val KEY_PRESET = "preset"
        const val KEY_PROGRESS = "progress"; const val KEY_OUTPUT = "output"
        const val KEY_ERROR = "error"
        private const val CHANNEL = "exports"; private const val NOTIF_ID = 1
    }
}
